<?php
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");

$file = "CryptoData1.txt";
$data = file_get_contents($file);
$array =json_decode($data,true);


foreach($array as $row){
    $id =$row["id"];
    $icon =$row["icon"];
    $name =$row["name"];
    $symbol =$row["symbol"];
    $rank =$row["rank"];
    $price =$row["price"];
    $priceBtc =$row["priceBtc"];
    $volume =$row["volume"];
    $marketcap = $row["marketCap"];
    $circulating_supply=$row["totalSupply"];
    $query = "UPDATE watchlist set price='$price', priceBtc= '$priceBtc' where id='$id'";
    $res = mysqli_query($connect,$query)
    or die ("cannot update...");
    
}


echo "The Watchlist has successfully been updated";
 



?>
