<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminate Order</title>
</head>
<body>
    <?php
    if(isset($_REQUEST['id'])){
require_once('config.php');
$identity = $_REQUEST['id'];
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");

/*Find the balance first */
$queryk = "SELECT amount FROM userbalance where user_id=$id";
    $resultk = mysqli_query($connect,$queryk)
    or die ("Could Not get the bitcoin price");

    $dollar=0;
    while($row = mysqli_fetch_array($resultk)){
    $dollar=$row['amount'];
    
    }


$queryS = "SELECT * from transaction where id='$identity' ";
$res = mysqli_query($connect,$queryS)
or die ("Could not get the data from the database");
/* Get the transaction information first*/

while($row = mysqli_fetch_array($res)){
    $quantity=$row['quantity'];
    $id=$row['user_id'];
    $symbol=$row['symbol'];
    $priceBtc=$row['total'];
    $order=$row['order_type'];


$queryx = "SELECT priceBtc,price FROM watchlist where symbol='BTC'";
    $resultk = mysqli_query($connect,$queryx)
    or die ("Could Not get the bitcoin price");
 
    while($row = mysqli_fetch_array($resultk)){
    $btc=$row['priceBtc'];
    $original = $row['price'];
    $Bitcoin  =$btc;
    }
   
/* Find the market price at the time of the transaction */
$queryT = "SELECT total,quantity from transaction where user_id=$id and id=$identity";
    $resultT = mysqli_query($connect,$queryT)
    or die ("Could Not get the Market price at the transaction time");
$marketprice =0;
$total=0;

    while($row = mysqli_fetch_array($resultT)){
        $total=$row['total'];
        $quantity=$row['quantity'];
        $marketprice =$total/$quantity;
    }
 

$difference=$Bitcoin-$marketprice;





/* update the user balance*/


$queryz = "UPDATE userbalance set amount=amount+(($quantity*$marketprice)*$original) where user_id=$id";
echo"the query is holding these values $queryz";
$resultx = mysqli_query($connect,$queryz)
or die ("Could Not update userbalance");



/*Add to history table first */
$query1 = "INSERT INTO history (id,quantity,user_id,symbol,total,time,order_type,profit_loss,order_id)
                VALUES (default,'$quantity','$id','$symbol','$total',CURRENT_TIMESTAMP,'$order','$difference','$identity')";
     $res1 = mysqli_query($connect,$query1)
     or die ("Could not insert the order into the history table.");
    
/*Remove from the in progress transactions */
$query = "DELETE FROM transaction WHERE id = $identity";

$res2 = mysqli_query($connect,$query)
        or die ("Could not Remove the order from the transaction.");

}     
       
}
mysqli_close($connect);
  header("Location: orders.php");  
 
?>
</body>
</html>