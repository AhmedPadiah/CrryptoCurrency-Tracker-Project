<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="main.css" type="text/css">
    <link rel="stylesheet" href="potfolio.css" type="text/css">
    <script type="text/javascript" src="script.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img\favicon.ico" />
    <title>Orders</title>
</head>
<body>
    
		<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				
				<li class="page"><a href="Watchlist.html" >Watchlist</a></li>
				<li class="page"><a href="tradepage.php" >Trade</a></li>
				<li class="page"><a href="potfolio.php">Track Potfolio</a></li>
				<li class="page"><a href="wallet.php">Wallet</a></li>
                <li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		<div class="cryptohopper-web-widget" data-id="2"></div>
		 
		</div>
		 <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				
				<li><a href=settings.php>Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
			
		</div>
        <div class="tn" id="myTopnav">
<a href="potfolio.php" >Ratio Visualization</a>
<a href="orders.php">Orders</a>
<a href="reports.php">Reports</a>

<a href="javascript:void(0);" class="icon" onclick="myFunction()">
 <i class="fa fa-bars"></i>
</a>
</div>
<?php
include('session.php');
?>
<?php
    require_once('config.php');
    $connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
    die("Cannot Connect to the database");
       $query = "SELECT transaction.id,logo,priceBtc,order_type,transaction.symbol,time,quantity,sum(total) 
       as total from transaction inner join 
       watchlist on watchlist.symbol=transaction.symbol && user_id=$id  group by symbol having order_type!='pending' limit 4";
       $res = mysqli_query($connect,$query)
       or die ("Could not select the query where the order type is not 'pending'...");

       echo"<table class=\"table \">
       <caption><h1>TRANSACTION IN PROGRESS</h1></caption>
       <tr>
           <th>Symbol</th>
           <th>Transaction Price</th>
           <th>Value</th>
           <th>Quantity</th>
           <th>Order Type</th>
           <th colspan=\"2\">Time</th>
       </tr>
           
       </tbody>";
    while($row = mysqli_fetch_array($res)){
         echo"<tr>";
         echo"<td>".'<img src="'.$row['logo'].' " width="20px" height="20px".>'.$row['symbol']."</td>";
         echo"<td>".$row['priceBtc']."</td>";
         echo"<td>".$row['total']."</td>";
         echo"<td>".$row['quantity']."</td>";
         echo"<td>".$row['order_type']."</td>";
         echo"<td>".$row['time']."</td>";
         $x =$row['id'];
         echo"<td>"."<a href=\"terminate.php?id=".$row['id']."\" name=\"cancel\">Close</a>"."</td>";
      
         } 
      
      echo"</table> ";
      
      $query2 = "SELECT logo,order_type,transaction.symbol,time,quantity,sum(total) 
      as total from transaction inner join 
      watchlist where user_id=$id && watchlist.symbol=transaction.symbol  group by symbol having order_type='pending' limit 5";
      $result = mysqli_query($connect,$query2)
      or die ("Something Went wrong ...");

      echo"<table class=\"table \" id=\"table2\">
      <caption><h1>PENDING ORDERS</h1></caption>
      <tr>
          <th>Symbol</th>
          <th>Value</th>
          <th>Quantity</th>
          <th>Time</th>
      </tr>
          
      </tbody>";
   while($row = mysqli_fetch_array($result)){
        echo"<tr>";
        echo"<td>".'<img src="'.$row['logo'].' " width="20px" height="20px".>'.$row['symbol']."</td>";
        echo"<td>".$row['total']."</td>";
        echo"<td>".$row['quantity']."</td>";
        echo"<td>".$row['time']."</td>";
        
     
        } 
     
     echo"</table> ";
     
    ?>
</body>
</html>