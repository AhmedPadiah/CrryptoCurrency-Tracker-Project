<?php
include('session.php');
?>
<html>
	<head>
		<link rel="stylesheet" href="index.css" type="text/css">
	
        <script src="script.js"></script>
		
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=PT+Sans">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@1,200&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link rel="icon" href="img\favicon.ico" />
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital@1&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://www.cryptohopper.com/widgets/js/script"></script>
		<title>SpecieSwap Tracker</title>

	</head>
	
	<body>
		
		<div class="Top_navigation">
		<nav>
			
			<ul>
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				<li class="page"><a href="Watchlist.html" >Watchlist</a></li>
				<li class="page"><a href="tradepage.php" >Trade</a></li>
				<li class="page"><a href="potfolio.php">Track Potfolio</a></li>
				<li class="page"><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>
			</ul>
		</nav>
		
			 <!-- <div id="search">
				 <form action = "PROJECT.php" method = "POST">
    <i class="fas fa-search"></i>
    <input type = "search" name = "search" placeholder = "coin name" >
    <input type = "submit" name = "submit" value = "go" ></div> -->
		 <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				<li><a href=settings.php>Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
			
		</div>
		<div class="cryptohopper-web-widget" data-id="2"></div>
		 <main> 
		<img src="img\bitcoin-3499244_960_720.jpg" alt="image"
			width="100%"
			height="570px"
			 />
	
	</body>

<footer class="page-footer font-small blue-grey lighten-5">

<div style="background-color: #21d985;">
  <div class="container">
	<div class="row py-4 d-flex align-items-center">
	  <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
		<h6 class="mb-0"></h6>
	  </div>

	</div>

  </div>
</div>

<div class="container text-center text-md-left mt-5">

  <div class="row mt-3 dark-grey-text">

	<div class="col-md-3 col-lg-4 col-xl-3 mb-4">

	  <h6 class="text-uppercase font-weight-bold">ABOUT SPECIE SWAP</h6>
	  <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
	  <p> Specie swap is Cryptocurrency tracker that was built by a group of 4
		   Rhodes university students to make cryptocurrencies such as bitcoin and other trading coins accessible to everyone-whenever and to whoever </p> 
	</div>
	<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

	  <h6 class="text-uppercase font-weight-bold">Useful links</h6>
	  <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
	  <p>
		<a class="dark-grey-text" href="settings.php">Your Account</a>
	  </p>
	  <p>
		<a class="dark-grey-text" href="watchlist.html">Watchlist</a>
	  </p>
	  <p>
		<a class="dark-grey-text" href="infocetre.html">Help</a>
	  </p>

	</div>
	<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

	  <h6 class="text-uppercase font-weight-bold">Contact</h6>
	  <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
	  <p>
	  <i class="fa fa-map-marker"></i> Rhodes University , Makhanda, RSA</p>
	  <p>
	  <i class="fa fa-envelope-o"></i> specieswap@campus.ru.ac.za</p>
	  <p>
	  <i class="fa fa-phone"></i> 046 0528 579</p>
	  <p>
	  <i class="fa fa-fax"></i> 046 785 968</p>

	</div>
  </div>

</div>

<div class="footer-copyright text-center text-black-50 py-3">© 2020 Copyright:
  <a class="dark-grey-text" href="#"> SpecieSwap</a>
</div>

</html>