 <?php
include('session.php');

?>
<?php
$Watchlistid=$_GET['id'];
$price =$_GET['price'];
$name =$_GET['name'];
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");
   $query = "SELECT * from watchlist where id='$Watchlistid'";
   $res = mysqli_query($connect,$query)
   or die ("Something Went wrong heeeeeeee ...");
   
   while($row = mysqli_fetch_array($res)){
    $logo = $row['logo'];
    $price =$row['price'];
    $priceBtc =$row['priceBtc'];
    $symbol =$row['symbol'];
   
   }

   ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="trade.css" type="text/css">
    <script src="script.js"></script>
    <!DOCTYPE html>
<html>
<head>

<title>Trade page</title>
</head>
<body>
<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				>
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		</div>
        <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocetre.html">Information Centre</a></li>
				
				<li><a href="settings.php">Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
		</div>
        <div class="menu-bg" id="menu-bg"></div>


</div>

    <div class="trade-page">
      <div class="form">
        <div class="trade">
          <div class="trade-header">
            
            <p><?php echo"<img src=$logo>"."<h4>".$symbol."</h4>"?></p>
          </div>
        </div>
        <p><?php echo "<h2><i>Price : $ $priceBtc</i></h2?"?></p>
        <form class="trade-form" action="transaction.php" method="GET">
          <input type="number" placeholder="Quantity" min=1 max=100 id="quantity" name="quantity" required/>
         <input type="hidden" name="priceBtc" value="<?php echo $priceBtc?>">
         <input type="hidden" name="symbol" value="<?php echo $symbol?>">
          <input type="submit" value="BUY" id="buy" name="buy" />
          <input type="submit" value="SELL" id="sell" name="sell"/>
          <input type="submit" value="PENDING ORDER" id="pending" name="pending"/>
         
        
        </form>
      </div>
    </div>
<footer>
  
</footer>
</body>
</html>

