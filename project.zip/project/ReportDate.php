<?php
include('session.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script type="text/javascript" src="script.js"></script>
    <link rel="stylesheet" href="main.css" type="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="main.css" type="text/css">
    <link rel="stylesheet" href="potfolio.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img\favicon.ico" />
    <title>Trade History</title>
</head>
<body>
    
		<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				
				<li class="page"><a href="Watchlist.html" >Watchlist</a></li>
				<li class="page"><a href="tradepage.php" >Trade</a></li>
				<li class="page"><a href="potfolio.php">Track Potfolio</a></li>
				<li class="page"><a href="wallet.php">Wallet</a></li>
        <li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>


			</ul>
		</nav>
		<div class="cryptohopper-web-widget" data-id="2"></div>
		 
		</div>
		 <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				
				<li><a href=settings.php>Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
			
		</div>
        <div class="tn" id="myTopnav">
<a href="potfolio.php" >Ratio Visualization</a>
<a href="orders.php">Orders</a>
<a href="reports.php">Reports</a>

<a href="javascript:void(0);" class="icon" onclick="myFunction()">
 <i class="fa fa-bars"></i>
</a>
</div>
<?php 
        
        if(isset($_REQUEST['submit'])){
         
                 require_once('config.php');
        
                 $id=$_SESSION['id'];
                 $datefrom =$_REQUEST['fromdate'];
                 $dateto =$_REQUEST['todate'];
                 $datefrom1 = $datefrom." 0:00:00";
                 $dateto1= $dateto." 23:59:00";
       
       
        
                 $connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
                 die("Cannot Connect to the database"); 
                 
                 $query= " SELECT symbol,count(total) as total,quantity,time from history where user_id=$id && time 
        between'$datefrom1' and '$dateto1' group by symbol";
        $result = mysqli_query($connect,$query)
        or die ("Something Went wrong with the query");

      
        
        echo"<table class=\"table \">
               <caption><h1>COINS TRADED</h1></caption>
               <tr>
                   <th>Symbol</th>
                   <th>Quantity</th>
                   </tr>";
        
               
        while($row = mysqli_fetch_array($result)){
          $symbol=$row['symbol'];
          $quantity=$row['quantity'];
        
          echo"<tr>";
                 echo"<td>".$row['symbol']."</td>";
                 echo"<td>".$row['quantity']."</td>";
        }
        
        echo"</table> ";
        }
        echo "<div align='center'>" ."<strong>FOR THE PERIOD</strong>". " $datefrom1"." ". "<strong>to the period</strong>"." ". "$dateto1"." ". "<strong> THE ABOVE TRADES WERE COMPLETED</strong>"."</div>";
         ?>
          
          </body>
</html>