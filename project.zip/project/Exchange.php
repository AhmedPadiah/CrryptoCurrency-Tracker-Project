<?php
include('session.php');
?>

<?php
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");
   $query = "SELECT priceBtc from watchlist where id='bitcoin' ";
   $res = mysqli_query($connect,$query)
   or die ("Something Went wrong ...");
   
	while($row = mysqli_fetch_array($res)){
	$price =$row['priceBtc'];
	
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="main.css" type="text/css">
    <link rel="stylesheet" href="exchange.css" type="text/css">
	<link rel="icon" href="img\favicon.ico" />
    <script src="script.js"></script>
    <title>Watchlist</title>

</head>
<body>
<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				<li class="active"><a href="Exchange.php">Exchange Rates</a></li>
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"></a><i class="fa fa-home" style="font-size:20px;color:white"></i></li>

			</ul>
		</nav>
		<div class="cryptohopper-web-widget" data-id="2"></div>

		</div>
		 <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				
				<li><a href=settings.php>Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
			
		</div>

        <div class="menu-bg" id="menu-bg"></div>
<div id="video">
<video autoplay muted loop id="myVideo">
			<source src="https://media.istockphoto.com/videos/stock-market-chart-animated-loop-front-red-green-video-id1262740092" type="video/mp4">
		  </video> 
</div>
		 
<div class="main-block">
    <h1>Currency Exchange</h1>
    <form action="#">

      
      <input type="text" id="btc" value='<?php echo $price ?>'></input>
	  <label > BTC</label><br>
     <input type="submit" value="Exchange" style="background-color: darkgreen; border:0px;color:whitesmoke;cursor:pointer;with:40px;"/><br>
      
      <input type="text" id="usd" ></input>
	  <label > USD</label>
      <div class="btn-block">
 
        
      </div>
    </form>
  </div>
 
	
</div>
</body>
</html>
