<?php

if(isset($_POST['user'])){
  $email = $_POST['user'];

  
  require_once("config.php");
  $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
or die("Could not access the Database");

/* 
$query = "SELECT id FROM user where email=$email ";
$result = mysqli_query($conn, $query) or die ("Unable to Read Data!");
 */

mysqli_close($conn);
}

?>