<?php
include('session.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img\favicon.ico" />
    <title>Withdraw</title>
</head>
<body>
<style>
    body {
    margin: 0;
    padding: 0;
    background-image: url("https://cdn4.vectorstock.com/i/1000x1000/59/43/glowing-line-with-sparks-light-effect-green-color-vector-23775943.jpg");
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-line-pack: center;
        align-content: center;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
    -webkit-box-pack: center;
        -ms-flex-pack: center;
            justify-content: center;
    min-height: 100vh;
    -ms-flex-wrap: wrap;
        flex-wrap: wrap;
    font-family: 'Raleway';
}

.payment-title {
    width: 100%;
    text-align: center;
}

.form-container .field-container:first-of-type {
    grid-area: name;
}

.form-container .field-container:nth-of-type(2) {
    grid-area: number;
}

.form-container .field-container:nth-of-type(3) {
    grid-area: expiration;
}

.form-container .field-container:nth-of-type(4) {
    grid-area: security;
}

.field-container input {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
}

.field-container {
    position: relative;
}

.form-container {
    display: grid;
    grid-column-gap: 10px;
    grid-template-columns: auto auto;
    grid-template-rows: 90px 90px 90px;
    grid-template-areas: "name name""number number""expiration security";
    max-width: 400px;
    padding: 20px;
    color: #707070;
}

label {
    padding-bottom: 5px;
    font-size: 13px;
    color: white;
}

input {
    margin-top: 3px;
    padding: 15px;
    font-size: 16px;
    width: 100%;
    border-radius: 3px;
    border: 1px solid #dcdcdc;
}

.ccicon {
    height: 38px;
    position: absolute;
    right: 6px;
    top: calc(50% - 17px);
    width: 60px;
}
#submit{
    margin-top : 20px;
    position: relative;
    
}
#submit:hover{
    cursor: pointer;
    background-color:#32CD32;
    border-radius: 30px;

}
h1{
    color: white;
}


    </style>
<div class="payment-title">
        <h1>Withdrawal Request</h1>
    </div>
 <form action="withdraw.php" method="POST">
    <div class="form-container">
        <div class="field-container">
            <label for="name">Name</label>
            <input id="name" maxlength="20" type="text" value="<?php echo "$name"?>">
        </div>

        <div class="field-container">
            <label for="Amount">Amount to Withdraw</label><span >
            <input id="amount" type="text" placeholder="$ 300" name="amount"/>
            <input type="submit" name="submit0" value="Request Amount" id="submit"/> 
            <a href="wallet.php" style="color:red">Cancel</a>
        </div>
    </div>
</form>

    <?php
if(isset($_REQUEST['submit0'])){
    $amount =$_REQUEST['amount'];

 
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");
  
    $query = "UPDATE userbalance set amount=amount-'$amount' where user_id=$id";
   $res = mysqli_query($connect,$query)
   or die ("Something Went wrong ...");
   header("Location:wallet.php");


   mysqli_close($connect);
}
   ?>

</body>
</html>
