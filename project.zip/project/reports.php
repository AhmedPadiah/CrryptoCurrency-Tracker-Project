<?php
include('session.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="main.css" type="text/css">
    <link rel="stylesheet" href="report.css" type="text/css">
    <link rel="stylesheet" href="potfolio.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img\favicon.ico" />
    <script src="script.js"></script>
    <title>RECORDS</title>
</head>
<body>
    
		<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				
				<li class="page"><a href="Watchlist.html" >Watchlist</a></li>
				<li class="page"><a href="tradepage.php" >Trade</a></li>
				<li class="page"><a href="potfolio.php">Track Potfolio</a></li>
				<li class="page"><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		<div class="cryptohopper-web-widget" data-id="2"></div>
		 
		</div>
		 <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				
				<li><a href=settings.php>Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
			
		</div>
        <div class="tn" id="myTopnav">
<a href="potfolio.php" >Ratio Visualization</a>
<a href="orders.php">Orders</a>
<a href="reports.php">Reports</a>

<a href="javascript:void(0);" class="icon" onclick="myFunction()">
 <i class="fa fa-bars"></i>
</a>
</div>
  

<?php

    require_once('config.php');
    $connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
    die("Cannot Connect to the database");
       $query = "SELECT quantity,user_id,history.symbol,total,time,order_type,profit_loss,order_id,logo FROM history inner join watchlist on history.symbol=watchlist.symbol where user_id=$id order by time ";
       $res = mysqli_query($connect,$query)
       or die ("Something Went wrong ...");
       
       echo"<table class=\"table \">
       <caption><h1>TRADE HISTORY</h1></caption>
       <tr>
           <th>Symbol</th>
           <th>Quantity</th>
           <th>Order Type</th>
           <th>Time</th>
           <th>Total</th>
           <th><strong>Profit/Loss</strong></th>
       </tr>
           
       </tbody>";

    while($row = mysqli_fetch_array($res)){
        $quantity=$row['quantity'];
       $id=$row['user_id'];
       $symbol=$row['symbol'];
       $priceBtc=$row['total'];
       $profit_loss=$row['profit_loss'];
       $order=$row['order_type'];
       $symbol = $row['symbol'];
       $time=$row['time'];
       $logo = $row['logo'];
       
         echo"<tr>";
         echo"<td>".'<img src="'.$logo.' " width="20px" height="20px".>'.$symbol."</td>";
         echo"<td>".$row['quantity']."</td>";
         echo"<td>".$row['order_type']."</td>";
         echo"<td>".$row['time']."</td>";
         echo"<td>".$row['total']."</td>";
         echo"<td>".$row['profit_loss']."</td>";
      
         } 
      
      echo"</table> ";
      ?>
     <div id="trades"> <form action="ReportDate.php" action="POST"><label for="Coins_over_time">View VIEW COIN QUANTITY FROM:</label><br>
      <input type="date" name="fromdate" >
      <br>
      <div id="trades"><label for="Coins_over_time">TO:</label><br>
      <input type="date" name ="todate" /><br>
      <input type="submit" name="submit" value="Submit"/>
      
        </div>
        </div>
        
        
        </body>
        </html>