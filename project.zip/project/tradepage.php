<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="icon" href="img\favicon.ico" />
	<script src="script.js"></script>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=PT+Sans">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@1,200&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link rel="icon" href="img\favicon.ico" />
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital@1&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://www.cryptohopper.com/widgets/js/script"></script>
    <link rel="stylesheet" href="main.css">
	<link rel="stylesheet" href="tradepage.css">
	
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <script src="script.js"></script>
    <title>Wallet</title>
</head>
<body>
<style>
	
	</style>
    <div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
			
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		</div>
        <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				
				<li><a href="infocentre.html">Information Centre</a></li>
				
				<li><a href="settings.php">Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
		</div>
        <div class="menu-bg" id="menu-bg"></div>


</div>

<div id="widget">
	
</div>

<div class="crypto-price--container">
  <div class="c-container--ulcontainer">
    <ul class="coin-list--ul" data-js="price-ul"></ul>
  </div>
</div>
</div>
<div id="mini">
<?php

require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");
   $query = "SELECT * from watchlist order by price desc limit 100";
   $res = mysqli_query($connect,$query)
   or die ("Something Went wrong ...");

echo "<table id=\"table\">
<thead>
 <tr>
   
   <th>Symbol</th>
   <th>Price</th>
   <th colspan=\"3\">Volume</th>
  
 </tr>
</thead>
<tbody>";



while($row = mysqli_fetch_array($res)){
$pic =$row['logo'];
$Watchlistid=$row['id'];
$logo = $row['logo'];
$price =$row['price'];
$name =$row['symbol'];
   echo"<tr>";
   echo"<td>".'<img src="'.$pic.' " width="20px" height="20px".>'.$name."</td>";
   echo"<td>".$row['priceBtc']."</td>";
   echo"<td>".$row['volume']."</td>";
  
   echo"<td>"."<a href=\"trade.php?id=".$row['id']."&price=".$row['priceBtc']."&logo=".$row['logo']."&name=".$row['symbol']."\">Trade</a>"."</td>";
   } 
echo"</table> ";
?>
</div>

 
</div>
  </div>
</div>
</body>
</html>
