<?php 
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img\favicon.ico" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
    <title>transaction in Progress</title>
</head>
<body>
<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		</div>
        <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocetre.html">Information Centre</a></li>
				
				<li><a href="settings.php">Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
		</div>
        <div class="menu-bg" id="menu-bg"></div>


</div>

<?php

require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");



 if(isset($_GET['buy'])){
    $query0 = "SELECT amount from userbalance where user_id= '$id'";
   $result0 = mysqli_query($connect,$query0)
   or die ("Something Went wrong ...");
   

   $total= 0;
   $amount=0;
   while($row = mysqli_fetch_array($result0)){
	   $amount=$row['amount'];
}

 $quantity = $_REQUEST['quantity'];
$priceBtc = $_REQUEST['priceBtc'];
$symbol = $_REQUEST['symbol'];


$queryx = "SELECT price FROM cct5.watchlist where symbol='BTC'";
$resultx = mysqli_query($connect,$queryx)
or die ("Could Not get the bitcoin price");
while($row = mysqli_fetch_array($resultx)){
$Bitcoin=$row['price'];
}

/* amount in btc */
$amount = $amount/$Bitcoin;
if ($amount > $priceBtc){

$query = "INSERT INTO transaction (id,quantity,user_id,symbol,total,time,order_type)
            VALUES (default,'$quantity','$id','$symbol','$priceBtc'*'$quantity',CURRENT_TIMESTAMP,'buy')";


 $res = mysqli_query($connect,$query)
 or die ("Something Went wrong ...");

 $amt  = $amount -($priceBtc*$quantity);

 $amount1 = $amt*$Bitcoin;
 
 $query1 = "UPDATE userbalance set amount='$amount1' where user_id='$id'";

   $res1 = mysqli_query($connect,$query1)
   or die ("Something Went wrong ...");

 
  header("Location : tradepage.php");

 }
}
 else if(isset($_GET['sell'])){
    $query0 = "SELECT amount from userbalance where user_id= '$id'";
   $result0 = mysqli_query($connect,$query0)
   or die ("Something Went wrong ...");
   

   $total= 0;
   $amount=0;
   while($row = mysqli_fetch_array($result0)){
	   $amount=$row['amount'];
}
$queryx = "SELECT price FROM cct5.watchlist where symbol='BTC'";
$resultx = mysqli_query($connect,$queryx)
or die ("Could Not get the bitcoin price");

while($row = mysqli_fetch_array($resultx)){
$Bitcoin=$row['price'];
}
$amount = $amount/$Bitcoin;
;
echo "$amount";
 $quantity = $_REQUEST['quantity'];
$priceBtc = $_REQUEST['priceBtc'];
$symbol = $_REQUEST['symbol'];

if ($amount > $priceBtc){
    echo "$amount";
    $query = "INSERT INTO transaction (id,quantity,user_id,symbol,total,time,order_type)
    VALUES (default,'$quantity','$id','$symbol','$priceBtc'*'$quantity',CURRENT_TIMESTAMP,'sell')";

 $res = mysqli_query($connect,$query)
 or die ("Something Went wrong ...");
 $amt  = $amount -($priceBtc*$quantity);
 echo "amt";
 $amount1 = $amt*54223.7;;
 $query1 = "UPDATE userbalance set amount='$amount1' where user_id=$id";
   $res1 = mysqli_query($connect,$query1)
   or die ("Something Went wrong ...");

   $alert = "<script>alert(\"Successful\")</script>";
   echo $alert;


 header("Location : tradepage.php");


}}
else if(isset($_GET['pending'])){
    $quantity = $_REQUEST['quantity'];
    $priceBtc = $_REQUEST['priceBtc'];
    $symbol = $_REQUEST['symbol'];
    $query1 = "INSERT INTO transaction (id,quantity,user_id,symbol,total,time,order_type)
                VALUES (default,'$quantity','$id','$symbol','$priceBtc'*'$quantity',CURRENT_TIMESTAMP,'pending')";
    
     $res = mysqli_query($connect,$query1);
     header("Location : tradepage.php");
    }
 
?> 
</body>
</html>
