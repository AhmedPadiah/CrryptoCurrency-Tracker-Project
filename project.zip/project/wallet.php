
<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="icon" href="img\favicon.ico" />
   
  
    <link rel="stylesheet" href="wallet.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <script src="script.js"></script>
    <title>Wallet</title>
</head>
<body>
    <div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		</div>
        <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				
				<li><a href="settings.php">Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
		</div>
        <div class="menu-bg" id="menu-bg"></div>


</div>

<div class="wallet-container text-center">
	
<p class="page-title"><i class="fal fa-wallet"></i>
	<strong> My SpecieWallet</strong> <i class="fa fa-user"></i></p><br><br>


<div class="amount-box  text-center">
	<img src="1061163_cash_checkout_credit card_journey_money_icon.png">

     <?php
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");

   $query = "SELECT amount from userbalance where user_id= $id";
   $result = mysqli_query($connect,$query)
   or die ("Something Went wrong ...");
   

   $total= 0;
   $amount=0;
   while($row = mysqli_fetch_array($result)){
	   $amount=$row['amount'];
 	$total= $total +$amount;
}

$queryx = "SELECT price FROM cct5.watchlist where symbol='BTC'";
$resultx = mysqli_query($connect,$queryx)
or die ("Could Not get the bitcoin price");

while($row = mysqli_fetch_array($resultx)){
$Bitcoin=$row['price'];
}
$val = $total/$Bitcoin;

mysqli_close($connect);

?>
<p>Wallet Balance</p>
<p class="amount">$  <?php echo "$total"; ?> </p>
<h4> <?php echo "$val"?> BTC</h4>



</div> 
<div class="btn-group  text-center">
<a href="deposit.php" id="dps" style="color:white; border:2px solid green;">Deposit<a><br><br>

<a href= "withdraw.php" id="wit" style="color:white;border:2px solid green;">Withdraw</a>

</div>
<?php
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");
$query2 = "SELECT logo,transaction.symbol,sum(total) as total from transaction inner join watchlist on transaction.symbol=watchlist.symbol where user_id=$id group by symbol limit 5";
$result = mysqli_query($connect,$query2)
or die ("Something Went wrong ...");
echo"<p><b>COINS</b></p>";
while($row = mysqli_fetch_array($result)){
	$symbol=$row['symbol'];
	$total=$row['total'];
	$pic=$row['logo'];
	
echo"<div class=\"txn-history\">
<P class='txn-list'><img src=".$pic." width=\"20px\" height=\"20px\".>$symbol<span class=\"coin-amount\">$total</span></P>
</div>"
;}

?>


</body>

</html>
