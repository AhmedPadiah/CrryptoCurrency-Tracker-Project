
/*This is for the hangburger Menu */

function onClickMenu(){
	document.getElementById("menu").classList.toggle("change");
	document.getElementById("nav").classList.toggle("change");
	
	document.getElementById("menu-bg").classList.toggle("change-bg");
	document.getElementById("logo").classList.toggle("change-logo");
}


/*Login & Signup */
document.querySelector('.img-btn').addEventListener('click', function()
	{
		document.querySelector('.cont').classList.toggle('s-signup')
	}
); 

function myFunction() {
	var x = document.getElementById("myTopnav");
	if (x.className === "tn") {
	  x.className += " responsive";
	} else {
	  x.className = "topnav";
	}
  }


  function openNav() {
	document.getElementById("mySidenav").style.width = "250px";
  }
  
  function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
  }