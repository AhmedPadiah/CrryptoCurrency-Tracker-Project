<?php
include('session.php');
?>
<?php
$Watchlistid=$_GET['id'];
$price =$_GET['price'];
$name =$_GET['name'];
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");

   $query = "INSERT into coin (symbol,user_id,watchlist_id,price) values('$name','$id','$Watchlistid','$price')";
   $res = mysqli_query($connect,$query)
   or die ("Something Went wrong ...");
   echo "Coin Added to Wallet";
   header("Location:trade.php");
  
  mysqli_close($conn);

  // need to parse data from the previous page : dont edit anything please