<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img\favicon.ico" />
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="script.js"></script>
    <link rel="stylesheet" href="main.css" type="text/css">
    <link rel="stylesheet" href="potfolio.css" type="text/css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:ital,wght@1,300&display=swap" rel="stylesheet">
<title>Track Portfolio </title>



  </head>
  <body>
    
	<body>
		
		<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
        <li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>

		</div>
		 <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocentre.html">Information Centre</a></li>
				<li><a href=settings.php>Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>	
		</div>
    <div class="tn" id="myTopnav">
<a href="potfolio.php" >Ratio Visualization</a>
<a href="orders.php">Orders</a>
<a href="reports.php">Reports</a>

<a href="javascript:void(0);" class="icon" onclick="myFunction()">
 <i class="fa fa-bars"></i>
</a>
</div>
    <section>
    <script type="text/javascript">
 google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);

function drawChart() {

<?php 
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
    die("Cannot Connect to the database");
   
$query = "SELECT  distinct symbol,total FROM transaction where user_id=$id";

$res = mysqli_query($connect,$query)
or die ("Something Went wrong with the query");
echo "var data = google.visualization.arrayToDataTable([";
        echo"['Symbol','price'],";
        while($row = mysqli_fetch_array($res)){
            echo "['".$row['symbol']."',".$row['total']."],";
        }
        echo "]);";

        mysqli_close($connect);
?>

var options = {title:'Amount Spent by top 5 customer',
    vAxis: {
          title: 'Rands'
    },
    hAxis: {
          title: 'Customers' },
          
          
};var options = {
          title: 'Coin quantity Possession ',
          pieHole: 0.4,
          backgroundColor: 'whitesmoke'
      
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>


</section>

    <div id="donutchart" style="width: 100%; height: 900px;align-content:centre;"></div>
   <!--  <div id="trades"> <form action="potfolio.php" action="POST"><label for="Coins_over_time">View Coin quantity from :</label><br>
      <input type="date" name="from" >
      <div id="trades"><label for="Coins_over_time">To :</label>
      <input type="date" name ="to" ><br>
      this is an example of  the query but I hard coded it , so next to each  date input time ,please put the time input type  and replace it with the format i show below (dont forget that there must be a space between time and date):
      SELECT symbol,sum(total) as total,quantity,time from transaction where user_id= 203 && time between'2021-10-18(to be replaced with $date) 21:08:07( to be replaced with $time)' and '2021-10-18 21:21:38' group by symbol
      <p></p>
    </div> -->
  
</table> </div>
  </body>
</html>