<?php

require_once("config.php");

$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE);
$email = $_POST['email']; 

if (isset($_POST['signup.php'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

$sql_e = "SELECT * FROM users WHERE email='$email'";
$res_e = mysqli_query($conn, $sql_e);


if(mysqli_num_rows($res_e) > 0){
$email_error = "Sorry... email already taken";   

}else{
    $query = "INSERT INTO users ( email, password) 
             VALUES ('$email', '$password')";
    $results = mysqli_query($conn, $query);
    echo 'Saved!';
    exit();
}
} 




?>