<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Account.css">
    <link rel="stylesheet" type="text/css" href="potfolio.css">
    <script src="script.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
  <link rel="icon" href="img\favicon.ico" />
    <title>Settings</title>
</head>


<form action="settingsupdate.php" method="POST">
<div class="tn" id="myTopnav" style="position:relative;right:200%; width :30%">
<a href="index.php" >Home</a>


<a href="javascript:void(0);" class="icon" onclick="myFunction()">
 <i class="fa fa-bars"></i>
</a>
</div>
<body>
          <h2 style= "color:green;"><strong><?php echo $name ?> <?php echo $surname ?></strong></h2>
          
          <label>
            <span>First Name</span>
            <input type="text" name="first_name" id="first_name" value="<?php echo $name ?>" required><br>
          </label><br>
          <label>
       <label>
            <span>Last Name</span>
            <input type="text" name="last_name" id="last_name"  value="<?php echo $surname ?>" required><br>
          </label><br>
       <label>
            <span>Country</span>
            <input type="text"  name="country" id="country" value="<?php echo $country ?>"  required><br>
          </label><br>
       
          <label>
            <span>Email</span>
            <input type="email"  name="email" id="email"  value="<?php echo $email ?>" required><br>
          </label><br>
          <label>
            <span>Password</span>
            <input type="password" name="password" id="password" value="<?php echo $password ?>" required><br>
          </label><br><br>


          <button type="submit" class="submit"><input type="submit"  name="submit" value="Update Records"></button>
    <input type="hidden" name="id" value="<?php echo $id?>" >
        
      </form>

    

      </body>
</html>