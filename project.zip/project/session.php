<?php
//Start session
session_start();

if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
    header("location: account.php");
    exit();
}
$id=$_SESSION['id'];
$name=$_SESSION['name'];
$surname=$_SESSION['surname'];
$email=$_SESSION['email'];
$country=$_SESSION['country'];
$password =$_SESSION['password'];


?>