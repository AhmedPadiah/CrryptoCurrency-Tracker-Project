<?php
include('session.php');

?>
<?php
$Watchlistid=$_GET['id'];
$price =$_GET['price'];
$name =$_GET['name'];
require_once('config.php');
$connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
die("Cannot Connect to the database");
   $query = "SELECT * from watchlist where id='$Watchlistid'";
   $res = mysqli_query($connect,$query)
   or die ("Something Went wrong heeeeeeee ...");
   
   while($row = mysqli_fetch_array($res)){
    $logo = $row['logo'];
    $price =$row['price'];
    $priceBtc =$row['priceBtc'];
    $symbol =$row['symbol'];
   
   }

   ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="trade.css" type="text/css">
    <cove-markets-live-price-chart instrumentSelection="BTC-USD" maxWidth="800px" maxHeight="400px" border="1px solid gray" showBorder="true"></cove-markets-live-price-chart> <script type="module" defer src="https://cdn.jsdelivr.net/npm/@covemarkets/web-widgets@0.0.36/dist/live-price-chart/index.js"></script>
    <!DOCTYPE html>
<html>
<head>

<title>Trade page</title>
</head>
<body>
 
    <div class="trade-page">
      <div class="form">
        <div class="trade">
          <div class="trade-header">
            
            <p><?php echo"<img src=$logo>"."<h4>".$symbol."</h4>"?></p>
          </div>
        </div>
        <p><?php echo "<h2><i>Price : $ $priceBtc</i></h2?"?></p>
        <form class="trade-form" action="transaction.php" method="GET">
          <input type="number" placeholder="Quantity" min=1 max=10 id="quantity" name="quantity"/>
         <input type="hidden" name="priceBtc" value="<?php echo $priceBtc?>">
         <input type="hidden" name="symbol" value="<?php echo $symbol?>">
          <input type="submit" value="BUY" id="buy" name="buy" />
          <input type="submit" value="SELL" id="sell" name="sell"/>
        
        </form>
        
      </div>
    </div>

</body>
</html>

