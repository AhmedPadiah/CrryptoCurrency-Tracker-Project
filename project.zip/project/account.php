<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>User Access Account</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="Account.css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
  <link rel="icon" href="img\favicon.ico" />
</head>
<body>
 
    <div class="cont">
      <form action="account.php" method="POST">
      <div class="form sign-in">
        
        <h2>Sign In</h2>
        <label>
          <span>Email Address</span>
          <input type="email" name="email" id="email" required>
        </label>
        <label>
          <span>Password</span>
          <input type="password" name="password" id="password" required>
        </label>
        <button class="submit" type="button"><input type="submit" style="color:white;"  name="submit1" value="Sign In"></button>
        <p class="forgot-pass">Forgot Password ?</p>
  
      
      </div>
    </form>
     

    <div class="sub-cont">
      <div class="img">
        <div class="img-text m-up">
          <h2>New here?</h2>
          <p>Sign up and discover great amount of new Trading opportunities!</p>
        </div>
        <div class="img-text m-in">
          <h2>One of us?</h2>
          <p>If you already has an account, just sign in.</p>
        </div>
        <div class="img-btn">
          <span class="m-up">Sign Up</span>
          <span class="m-in">Sign In</span>
        </div>
      </div>
      
        <div class="form sign-up">
          <form action="account.php" method="POST">
          <h2>Sign Up</h2>
          
          <label>
            <span>First Name</span>
            <input type="text" name="first_name" id="first_name" required>
          </label>
          <label>
       <label>
            <span>Last Name</span>
            <input type="text" name="last_name" id="last_name" required>
          </label>
       <label>
            <span>Country</span>
            <input type="text"  name="country" id="country" required>
          </label>
       
          <label>
            <span>Email</span>
            <input type="email"  name="email" id="email" required>
          </label>
          <label>
            <span>Password</span>
            <input type="password" name="password" id="password" required>
          </label>
         
          <button type="button" class="submit"><input type="submit" style="color:white;"  name="submit2" value="Create Account"></button>
        
        </div>
      </form>
  
      </div>
    </div>
    
  </div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>
<?php

require_once("config.php");
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die ("couldn't connect to the database");
if(isset($_POST['submit2'])){
$fname = $_REQUEST['first_name'];
$lname = $_REQUEST['last_name'];
$email = $_REQUEST['email'];
$password = $_REQUEST['password'];
$country = $_REQUEST['country'];


$query1 = "INSERT INTO user (first_name,last_name,email,password,country)
            VALUE ('$fname','$lname','$email','$password','$country')";

$result = mysqli_query($conn,$query1) or die ("couldn't execute query");

$query = "SELECT * FROM user WHERE  password='$password' and email='$email'";
  
$result   = mysqli_query($conn,$query );
$row		  = mysqli_fetch_array($result);
$num_row 	= mysqli_num_rows($result);

if ($num_row > 0) 
  {			
   
    $_SESSION['id']=$row['id'];
    $_SESSION['name']= $row['first_name'];
    $_SESSION['surname'] = $row['last_name'];
    $_SESSION['email']= $row['email'];
    $_SESSION['country']=$row['country'];
    $_SESSION['password'] = $row['password'];

    $newAcc =  $_SESSION['id'];
    $queryM = "INSERT into userbalance(user_id,amount) values ('$newAcc','0')";
    $resultM = mysqli_query($conn,$queryM) or die ("couldn't create new user balance ");
    header('location:index.php');
    
  }

mysqli_close($conn);
header("Location : index.php");
}
else if(isset($_POST['submit1'])){
  
  $email = $_REQUEST['email'];
  $password = $_REQUEST['password'];

  $query = "SELECT * FROM user WHERE  password='$password' and email='$email'";
  
$result   = mysqli_query($conn,$query );
$row		  = mysqli_fetch_array($result);
$num_row 	= mysqli_num_rows($result);

if ($num_row > 0) 
  {			
    $_SESSION['user_id']=$row['id'];
    $_SESSION['name']= $row['first_name'];
    $_SESSION['surname'] = $row['last_name'];
    $_SESSION['email']= $row['email'];
    $_SESSION['country']=$row['country'];
    $_SESSION['password'] = $row['password'];
    header('location:index.php');
    
  }
else
  {
    echo 'Invalid Username and Password Combination';
    mysqli_close($conn);
header("Location : account.php");
  }

}
?>