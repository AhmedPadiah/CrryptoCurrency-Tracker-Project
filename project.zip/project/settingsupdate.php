<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>SETTINGS</title>
</head>
<body>
<div class="Top_navigation">
		<nav>
			
			<ul  >
				<a href="index.php" id="logo"><img src="img/logo.png"style="margin-left :145px;" height="100" width="200"></a>
				
				
				<li><a href="Watchlist.html" >Watchlist</a></li>
				<li><a href="tradepage.php" >Trade</a></li>
				<li><a href="potfolio.php">Track Potfolio</a></li>
				<li><a href="wallet.php">Wallet</a></li>
				<li class="page"><a href="index.php"><i class="fa fa-home" style="font-size:20px;color:white; position:center"></i></a></li>

			</ul>
		</nav>
		</div>
        <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="top" class="hangburger"></div>
				<div id="middle" class="hangburger"></div>
				<div id="bottom" class="hangburger"></div>
			</div>
			<ul class="nav" id="nav">
				<li><a href="infocetre.html">Information Centre</a></li>
				
				<li><a href="settings.php">Settings</a></li>
				<li><a href="account.php">Sign Out</a></li>
			</ul>
		</div>
        <div class="menu-bg" id="menu-bg"></div>

        <section class="admin">
<?php

        require_once('config.php');
       
        $id=$_REQUEST['id'];
        $name_up=$_REQUEST['first_name'];
        $surname_up=$_REQUEST['last_name'];
        $email_up=$_REQUEST['email'];
        $country_up=$_REQUEST['country'];
        $password_up =$_REQUEST['password'];
        $_SESSION['name'] = $name_up;
        $_SESSION['email'] =  $email_up;
        $_SESSION['country'] = $country_up;
        $_SESSION['password'] = $password_up;
		$_SESSION['surname'] = $surname_up;
        $connect =mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or 
        die("Cannot Connect to the database");

     
$query = "UPDATE user SET first_name='$name_up', last_name= '$surname_up', email= '$email_up', country= '$country_up', password= '$password_up' WHERE id=$id";
echo "the name is $name_up & the surname is '$surname_up ::: ";
$result = mysqli_query($connect,$query)
or die ("Something Went wrong ...");
echo "the results of the query is $query";
mysqli_close($connect);


header("Location : settings.php"); 

?>
</section>
</div>   
</body>
</html>

