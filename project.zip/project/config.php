<?php
define("SERVERNAME", "is3-dev.ict.ru.ac.za");
define("USERNAME","G18D4897");
define("PASSWORD" ,"G18DLADLAS");
define("DATABASE", "cct5");
?>
